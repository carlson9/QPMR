myX <- matrix(c(1,2,3,4,5,6,4,3,7,8,3,6,7,8,9),nrow=5)
myY <- c(3,5,6,5,7)
runLMImp(myX, myY)