#' LMPack
#'
#' The LMPack package runs linear models on combinations of covariates.  
#' @name LMPack
#' @docType package
#' @author  David G. Carlson: \email{carlson.david@@wustl.edu}
#'
NULL
