#' Example Dataset
#'
#' An example dataset
#'
#' The variables included in the dataset are:
#' \itemize{
#' \item\code{X} A matrix of observations
#' \item\code{Y} A vector of output variable
#'} 
#'
#' @name exampleDataset
#' @docType data
NULL
