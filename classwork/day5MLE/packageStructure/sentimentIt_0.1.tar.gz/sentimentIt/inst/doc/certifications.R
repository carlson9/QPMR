## ---- eval = FALSE-------------------------------------------------------
#  
#  checkCert(email = "johndoe@school.edu", password = "12345",
#            cert = "reviews", worker = "A115UFR6VA6OM1")
#  

## ---- eval = FALSE-------------------------------------------------------
#  
#  createCert(email = "johndoe@school.edu", password = "12345",
#            cert = "reviews", worker = "A115UFR6VA6OM1")
#  

## ---- eval = FALSE-------------------------------------------------------
#  
#  revokeCert(email = "johndoe@school.edu", password = "12345",
#            cert = "reviews", worker = "A115UFR6VA6OM1")
#  

