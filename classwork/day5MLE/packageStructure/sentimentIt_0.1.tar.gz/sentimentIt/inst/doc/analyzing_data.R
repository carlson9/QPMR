## ---- eval = FALSE-------------------------------------------------------
#  
#  #fitting a non-hierarchical Stan model using batch ID numbers
#  
#  stan_model <- fitStan(email = "johndoe@school.edu", password = "12345",
#                        data = batch_ids)
#  
#  #alternately, you can use the output from readInData()
#  
#  stan_model <- fitStan(data = comp_output)

## ---- eval = FALSE-------------------------------------------------------
#  
#  #merging the data frame from the stan model with the output from the
#  #readText() function (see the sending_data vignette). Both datasets
#  #should contain a column of unique document IDs, and we specify this
#  #column as the basis of the merge.
#  
#  merged_data <- merge(x = stan_model[[2]],
#                       y = reviews_with_ids,
#                       by = "ids")
#  

## ---- eval = FALSE-------------------------------------------------------
#  
#  #fitting a hierarchical Stan model
#  
#  stan_hier_model <- fitStanHier(email = "johndoe@school.edu", password = "12345",
#                            data = hier_batch_ids, hierarchy_data = hier_data_with_ids,
#                            hierarchy_var = hier_data_with_ids$document_id)
#  

## ---- eval = FALSE-------------------------------------------------------
#  
#  ban_workers <- checkWorkers(stan_fit = stan_model[[1]], data = comp_output)

